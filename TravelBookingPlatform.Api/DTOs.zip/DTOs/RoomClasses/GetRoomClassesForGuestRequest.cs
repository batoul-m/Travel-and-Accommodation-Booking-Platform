﻿using TravelBookingPlatform.Api.Dtos.Common;

namespace TravelBookingPlatform.Api.Dtos.RoomClasses;

public class GetRoomClassesForGuestRequest : ResourcesQueryRequest
{
}