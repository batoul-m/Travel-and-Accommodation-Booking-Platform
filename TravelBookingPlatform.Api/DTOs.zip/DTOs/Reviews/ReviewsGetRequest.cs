﻿using TravelBookingPlatform.Api.Dtos.Common;

namespace TravelBookingPlatform.Api.Dtos.Reviews;

public class ReviewsGetRequest : ResourcesQueryRequest
{
}