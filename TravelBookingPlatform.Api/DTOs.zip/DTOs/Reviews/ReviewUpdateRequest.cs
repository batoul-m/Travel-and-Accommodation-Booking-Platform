﻿namespace TravelBookingPlatform.Api.Dtos.Reviews;

public class ReviewUpdateRequest
{
  public string Content { get; init; }
  public int Rating { get; init; }
}