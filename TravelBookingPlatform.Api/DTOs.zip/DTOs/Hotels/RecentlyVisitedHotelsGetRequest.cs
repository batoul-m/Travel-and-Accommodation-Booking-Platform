﻿namespace TravelBookingPlatform.Api.Dtos.Hotels;

public class RecentlyVisitedHotelsGetRequest
{
  public int Count { get; init; }
}