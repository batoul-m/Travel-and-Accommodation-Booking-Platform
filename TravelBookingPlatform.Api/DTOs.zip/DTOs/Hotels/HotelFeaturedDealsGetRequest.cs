﻿namespace TravelBookingPlatform.Api.Dtos.Hotels;

public class HotelFeaturedDealsGetRequest
{
  public int Count { get; init; }
}