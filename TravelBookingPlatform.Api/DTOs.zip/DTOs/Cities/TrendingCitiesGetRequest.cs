﻿namespace TravelBookingPlatform.Api.Dtos.Cities;

public class TrendingCitiesGetRequest
{
  public int Count { get; init; }
}