﻿namespace TravelBookingPlatform.Api.Dtos.Rooms;

public class RoomCreationRequest
{
  public string Number { get; init; }
}