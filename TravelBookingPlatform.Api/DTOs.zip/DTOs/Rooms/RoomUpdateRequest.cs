﻿namespace TravelBookingPlatform.Api.Dtos.Rooms;

public class RoomUpdateRequest
{
  public string Number { get; init; }
}