﻿using TravelBookingPlatform.Api.Dtos.Common;

namespace TravelBookingPlatform.Api.Dtos.Discounts;

public class DiscountsGetRequest : ResourcesQueryRequest
{
}