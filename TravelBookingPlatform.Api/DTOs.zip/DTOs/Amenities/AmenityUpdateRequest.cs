﻿namespace TravelBookingPlatform.Api.Dtos.Amenities;

public class AmenityUpdateRequest
{
  public string Name { get; init; }
  public string? Description { get; init; }
}