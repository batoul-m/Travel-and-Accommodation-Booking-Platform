﻿namespace TravelBookingPlatform.Api.Dtos.Images;

public class ImageCreationRequest
{
  public IFormFile Image { get; init; }
}