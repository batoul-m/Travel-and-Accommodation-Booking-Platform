﻿using TravelBookingPlatform.Api.Dtos.Common;

namespace TravelBookingPlatform.Api.Dtos.Bookings;

public class BookingsGetRequest : ResourcesQueryRequest
{
}